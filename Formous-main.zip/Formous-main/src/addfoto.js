const addfoto = () => { 
	return `
	
	*ADICIONAR BASE DE DADOS FOTO*
	
	FOTOS COM SUCESSO SALVADAS NOS DADOS!
	

obrigado !`
}
exports.addfoto = addfoto